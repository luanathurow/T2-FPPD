package main

import (
	"fmt"
	"log"
	"net/rpc"
	"os"
)

type Jogador struct {
	ID    int
	Name  string
	Email string
}

type CreateJogadorRequest struct {
	Name  string
	Email string
}

type GetJogadorRequest struct {
	ID int
}

func clientFun() {
	if len(os.Args) < 2 {
		fmt.Println("Uso: go run client.go <endereço:porta>")
		os.Exit(1)
	}

	serverAddr := os.Args[1] // Ex: "localhost:1234"

	client, err := rpc.Dial("tcp", serverAddr)
	if err != nil {
		log.Fatal("Erro ao conectar:", err)
	}

	// Criar usuário
	createReq := CreateJogadorRequest{Name: "Maria", Email: "maria@example.com"}
	var newJogador Jogador
	err = client.Call("UserService.CreateUser", &createReq, &newJogador)
	if err != nil {
		log.Fatal("Erro ao criar usuário:", err)
	}
	fmt.Println("Usuário criado:", newJogador)

	// Obter usuário pelo ID
	var fetched Jogador
	getReq := GetJogadorRequest{ID: newJogador.ID}
	err = client.Call("UserService.GetUser", &getReq, &fetched)
	if err != nil {
		log.Fatal("Erro ao buscar usuário:", err)
	}
	fmt.Println("Usuário encontrado:", fetched)

	// Listar todos os usuários
	var allJogadores []Jogador
	err = client.Call("UserService.ListUsers", &struct{}{}, &allJogadores)
	if err != nil {
		log.Fatal("Erro ao listar usuários:", err)
	}

	fmt.Println("Todos os usuários:")
	for _, u := range allJogadores {
		fmt.Printf("ID: %d, Nome: %s, Email: %s\n", u.ID, u.Name, u.Email)
	}
}
