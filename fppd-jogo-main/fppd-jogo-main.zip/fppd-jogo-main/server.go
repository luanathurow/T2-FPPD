package main

import (
	"errors"
	"fmt"
	"log"
	"net"
	"net/rpc"
	"sync"
)

type Jogador struct {
	ID    int
	Name  string
	Email string
}

type CreateJogadorRequest struct {
	Name  string
	Email string
}

type GetJogadorRequest struct {
	ID int
}

type JogadorService struct {
	mu     sync.Mutex
	users  map[int]Jogador
	nextID int
}

func (s *JogadorService) CreateUser(req *CreateJogadorRequest, resp *Jogador) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	s.nextID++
	user := Jogador{ID: s.nextID, Name: req.Name, Email: req.Email}
	s.users[user.ID] = user
	*resp = user
	return nil
}

func (s *JogadorService) GetUser(req *GetJogadorRequest, resp *Jogador) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	user, ok := s.users[req.ID]
	if !ok {
		return errors.New("usuário não encontrado")
	}
	*resp = user
	return nil
}

func (s *JogadorService) ListUsers(_ *struct{}, resp *[]Jogador) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	var list []Jogador
	for _, user := range s.users {
		list = append(list, user)
	}
	*resp = list
	return nil
}

func serverFun() {
	service := &JogadorService{
		users:  make(map[int]Jogador),
		nextID: 0,
	}

	rpc.Register(service)
	listener, err := net.Listen("tcp", ":8932")
	if err != nil {
		log.Fatal(err)
	}
	fmt.Println("Servidor RPC iniciado em :8932")

	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Println("Erro ao aceitar conexão:", err)
			continue
		}
		go rpc.ServeConn(conn)
	}
}
